<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Liad Yosef

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
FredRTETinyMCE
---------------------------------------
Version: 1.0.0-beta
Author:  John Peca <john@modx.com>
---------------------------------------',
    'changelog' => 'Changelog for FredRTETinyMCE.

FredRTETinyMCE 1.0.0-beta
==============
- Initial release.',
    'requires' => 
    array (
      'fred' => '>=1.0.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8239f40b651794c6eab0dafb395db320',
      'native_key' => 'fredrtetinymce',
      'filename' => 'modNamespace/adf8d6002dc4ad56eb095f78cdb326bc.vehicle',
      'namespace' => 'fredrtetinymce',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5822b5226248758775721230ebf3f41b',
      'native_key' => NULL,
      'filename' => 'modCategory/be4b45c488dbbee34a96fdd2c6d365e9.vehicle',
      'namespace' => 'fredrtetinymce',
    ),
  ),
);