<?php

$_lang['fredrtetinymce.page'] = 'Page';
$_lang['fredrtetinymce.block_on'] = 'Block on \'[[+page]]\'';
$_lang['fredrtetinymce.anchor'] = 'Anchor Tag';
$_lang['fredrtetinymce.url'] = 'URL';
$_lang['fredrtetinymce.email'] = 'Email';
$_lang['fredrtetinymce.to'] = 'To';
$_lang['fredrtetinymce.subject'] = 'Subject';
$_lang['fredrtetinymce.body'] = 'Body';
$_lang['fredrtetinymce.phone'] = 'Phone';
$_lang['fredrtetinymce.file'] = 'File';
$_lang['fredrtetinymce.link_text'] = 'Link Text';
$_lang['fredrtetinymce.link_to'] = 'Link to';
$_lang['fredrtetinymce.ok'] = 'Ok';
$_lang['fredrtetinymce.cancel'] = 'Cancel';
$_lang['fredrtetinymce.remove_link'] = 'Remove Link';
$_lang['fredrtetinymce.link_title'] = 'Link Title';
$_lang['fredrtetinymce.classes'] = 'Classes';
$_lang['fredrtetinymce.new_window'] = 'New Window';
$_lang['fredrtetinymce.page_title'] = 'Page Title';
$_lang['fredrtetinymce.tooltip'] = 'Insert/Edit Link';