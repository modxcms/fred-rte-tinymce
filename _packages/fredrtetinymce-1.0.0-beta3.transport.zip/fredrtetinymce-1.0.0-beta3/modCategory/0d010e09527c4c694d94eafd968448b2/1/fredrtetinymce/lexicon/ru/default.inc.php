<?php

$_lang['fredrtetinymce.page'] = 'Страница';
$_lang['fredrtetinymce.block_on'] = 'Блокировать \'[[+page]]\'';
$_lang['fredrtetinymce.anchor'] = 'Якорная метка';
$_lang['fredrtetinymce.url'] = 'URL';
$_lang['fredrtetinymce.email'] = 'Электронный адрес';
$_lang['fredrtetinymce.to'] = 'Кому';
$_lang['fredrtetinymce.subject'] = 'Тема';
$_lang['fredrtetinymce.body'] = 'Тело';
$_lang['fredrtetinymce.phone'] = 'Телефон';
$_lang['fredrtetinymce.file'] = 'Файл';
$_lang['fredrtetinymce.link_text'] = 'Текст ссылки';
$_lang['fredrtetinymce.link_to'] = 'Ссылка к';
$_lang['fredrtetinymce.ok'] = 'Ок';
$_lang['fredrtetinymce.cancel'] = 'Отмена';
$_lang['fredrtetinymce.remove_link'] = 'Удалить ссылку';
$_lang['fredrtetinymce.link_title'] = 'Название ссылки';
$_lang['fredrtetinymce.classes'] = 'Классы';
$_lang['fredrtetinymce.new_window'] = 'Новое окно';
$_lang['fredrtetinymce.page_title'] = 'Заголовок страницы';
$_lang['fredrtetinymce.tooltip'] = 'Вставить/Изменить ссылку';