<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
FredRTETinyMCE
---------------------------------------
Version: 1.0.0-beta3
Author:  John Peca <john@modx.com>
---------------------------------------

To use the Fred TinyMCE RTE, change the value of the fred.rte system setting in the Fred namespace to "TinyMCE".',
    'changelog' => 'Changelog for FredRTETinyMCE.

FredRTETinyMCE 1.0.0-beta3
==============
- Sign XHR requests

FredRTETinyMCE 1.0.0-beta2
==============
- Add resolver to adjust IconEditor in system settings
- Add ru translations

FredRTETinyMCE 1.0.0-beta
==============
- Initial release.',
    'requires' => 
    array (
      'fred' => '>=1.0.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '01f28450e0541edf2e00bab86d929234',
      'native_key' => 'fredrtetinymce',
      'filename' => 'modNamespace/4e5a1c33c6444c0f8f0afc9587626329.vehicle',
      'namespace' => 'fredrtetinymce',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2bee64a222f9cae6014a93b88b8f38a0',
      'native_key' => NULL,
      'filename' => 'modCategory/0d010e09527c4c694d94eafd968448b2.vehicle',
      'namespace' => 'fredrtetinymce',
    ),
  ),
);