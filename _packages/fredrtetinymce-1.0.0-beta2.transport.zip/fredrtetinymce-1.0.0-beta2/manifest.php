<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '---------------------------------------
FredRTETinyMCE
---------------------------------------
Version: 1.0.0-beta2
Author:  John Peca <john@modx.com>
---------------------------------------

To use the Fred TinyMCE RTE, change the value of the fred.rte system setting in the Fred namespace to "TinyMCE".',
    'changelog' => 'Changelog for FredRTETinyMCE.

FredRTETinyMCE 1.0.0-beta2
==============
- Add resolver to adjust IconEditor in system settings
- Add ru translations

FredRTETinyMCE 1.0.0-beta
==============
- Initial release.',
    'requires' => 
    array (
      'fred' => '>=1.0.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5be5a67e29d210d98b1987efa0402857',
      'native_key' => 'fredrtetinymce',
      'filename' => 'modNamespace/bc4c8214f4d6dac10f13bc0395c7b446.vehicle',
      'namespace' => 'fredrtetinymce',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b48a06ca1f4abad1451534172ff578f5',
      'native_key' => NULL,
      'filename' => 'modCategory/baa58afce832e3d45a4af999e516e237.vehicle',
      'namespace' => 'fredrtetinymce',
    ),
  ),
);