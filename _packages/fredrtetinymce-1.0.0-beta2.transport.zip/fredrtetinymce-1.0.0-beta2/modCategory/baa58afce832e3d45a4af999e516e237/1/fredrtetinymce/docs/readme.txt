---------------------------------------
FredRTETinyMCE
---------------------------------------
Version: 1.0.0-beta2
Author:  John Peca <john@modx.com>
---------------------------------------

To use the Fred TinyMCE RTE, change the value of the fred.rte system setting in the Fred namespace to "TinyMCE".